import { Injectable } from '@angular/core';
import { Recipe } from '../models/recipe';

@Injectable({
  providedIn: 'root'
})
export class RecipeService {
  private recipes: Recipe[] = [
    {
      id: 'r1',
      title: 'Pizza',
      imageUrl: 'https://assets.afcdn.com/recipe/20151003/20052_w1024h768c1cx480cy300.jpg',
      ingredients: [
        '1 pâte à pizza (maison si possible)',
        '250 g de coulis de tomate',
        '1 blanc de poulet',
        '140 g de thon en boite',
        '8 tranches de chorizo'
      ]
    },
    {
      id: 'r2',
      title: 'Spaghetti',
      imageUrl: 'https://static.cuisineaz.com/400x320/i2142-spaghetti-a-la-sauce-tomate.jpg',
      ingredients : [
        '1 kg de spaghetti',
        '100 g de concentré de tomate',
        '2 c. à soupe d\'huile d\'olive',
        '4 petites oignons',
        '1 gousse d\'ail'
      ]
    }
  ];

  constructor() { }

  getAllRecipes() {
    return [...this.recipes];
  }

  getRecipe(recipeId: string) {
    return {
      ...this.recipes.find(recipe => {
        return recipe.id === recipeId;
      })
    };
  }

  deleteRecipe(recipeId: string) {
    this.recipes = this.recipes.filter(recipe => {
      return recipe.id !== recipeId;
    });
  }
}
